<?php
include 'db.php';

// --- Pagination Setup ---
$limit  = 5;
$page   = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// --- Build WHERE Clause ---
$where = [];
if (!empty($_GET['search'])) {
    $search = mysqli_real_escape_string($koneksi, $_GET['search']);
    $where[] = "nama_barang LIKE '%$search%'";
}
if (!empty($_GET['kategori'])) {
    $catId = (int)$_GET['kategori'];
    $where[] = "kategori_id = $catId";
}
$whereSql = !empty($where) ? ' WHERE ' . implode(' AND ', $where) : '';

// --- Count Total Rows ---
$countRes  = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM barang JOIN kategori ON barang.kategori_id=kategori.id" . $whereSql);
$totalRow  = mysqli_fetch_assoc($countRes)['total'];
$totalPage = ceil($totalRow / $limit);

// --- Fetch Data ---
$queryBarang = "SELECT b.*, k.nama_kategori FROM barang b JOIN kategori k ON b.kategori_id=k.id"
             . $whereSql
             . " ORDER BY b.id DESC LIMIT $limit OFFSET $offset";
$resultBarang = mysqli_query($koneksi, $queryBarang);

// --- Fetch Categories ---
$queryKategori  = "SELECT * FROM kategori";
$resultKategori = mysqli_query($koneksi, $queryKategori);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>List</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    .btn-ani { transition: transform .2s, box-shadow .2s; }
    .btn-ani:hover { transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
    #flash-msg { position: fixed; top: 1rem; right: 1rem; z-index: 1050; }
    #flash-msg .btn-close { margin-right: .5rem; }
    body { padding-bottom: 100px; }

    
     .table thead th {
      background-color: #ba181b;
      color: #edf2f4;           
    }
    /* Border ke seluruh tabel */
    .table-bordered th,
    .table-bordered td {
      border: 1px solid #023e7d;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid justify-content-center">
    <a class="navbar-brand mx-auto" href="index.php">RAIVEN</a>
  </div>
</nav>

<!-- Flash Message -->
<?php if (isset($_GET['pesan'])): ?>
<div id="flash-msg" class="alert alert-success alert-dismissible fade show" role="alert">
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  <?= htmlspecialchars($_GET['pesan']) ?>
</div>
<?php endif; ?>

<main class="container mt-5 ms-5">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h3">RANN INVENTARIS </h1>
  </div>
  <p class="text-muted mb-4">tempat List Inventaris</p>

  <!-- Filter Form -->
  <form class="row g-3 mb-4" method="GET">
    <div class="col-md-4">
      <input type="text" name="search" class="form-control btn-ani" placeholder="mau cari barang apa?" value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
    </div>
    <div class="col-md-3">
      <select name="kategori" class="form-select btn-ani">
        <option value="">-- Filter Kategori --</option>
        <?php mysqli_data_seek($resultKategori,0); while($cat = mysqli_fetch_assoc($resultKategori)): ?>
        <option value="<?= $cat['id'] ?>" <?= (isset($_GET['kategori']) && $_GET['kategori']==$cat['id'])?'selected':'' ?>>
          <?= htmlspecialchars($cat['nama_kategori']) ?>
        </option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="col-auto">
      <button type="submit" class="btn btn-primary btn-ani"><i class="bi bi-search me-1"></i>Filter/Cari</button>
    </div>
    <div class="col-auto">
      <a href="?<?= http_build_query(['page'=>1,'search'=>'','kategori'=>'']) ?>" class="btn btn-secondary btn-ani">
        <i class="bi bi-arrow-clockwise me-1"></i>Reset
      </a>
    </div>
  </form>

  <!-- Data Table -->
  <div class="table-responsive mb-4">
    <table class="table table-striped align-middle">
      <thead class="table-light">
        <tr>
          <th>No</th>
          <th>Nama Barang</th>
          <th>Kategori</th>
          <th>Stok</th>
          <th>Harga</th>
          <th>Tgl Masuk</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $no = $offset + 1; while($row = mysqli_fetch_assoc($resultBarang)): ?>
        <tr>
          <td><?= $no++ ?></td>
          <td><?= htmlspecialchars($row['nama_barang']) ?></td>
          <td><?= htmlspecialchars($row['nama_kategori']) ?></td>
          <td><?= $row['jumlah_stok'] ?></td>
          <td>Rp <?= number_format($row['harga_barang'],0,',','.') ?></td>
          <td><?= htmlspecialchars($row['tanggal_masuk']) ?></td>
          <td>
            <a href="edit_barang.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-primary btn-ani">
              <i class="bi bi-pencil"></i>
            </a>
            <button onclick="if(confirm('Yakin menghapus barang ini?'))location='hapus_barang.php?id=<?= $row['id'] ?>'"
                    class="btn btn-sm btn-outline-danger btn-ani">
              <i class="bi bi-trash"></i>
            </button>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination Minimalis dengan < dan > -->
<nav class="mb-3">
  <ul class="pagination justify-content-center">
    <?php if($page > 1): ?>
      <li class="page-item">
        <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page'=>$page-1])) ?>">&lt;</a>
      </li>
    <?php endif; ?>

    <?php for($i=1; $i<=$totalPage; $i++): ?>
      <li class="page-item <?= ($page==$i)?'active':'' ?>">
        <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page'=>$i])) ?>">
          <?= $i ?>
        </a>
      </li>
    <?php endfor; ?>

    <?php if($page < $totalPage): ?>
      <li class="page-item">
        <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page'=>$page+1])) ?>">&gt;</a>
      </li>
    <?php endif; ?>
  </ul>
</nav>

</main>

<!-- Footer with Quick Actions -->
<footer class="bg-light text-center py-4 fixed-bottom">
  <div class="container d-flex justify-content-between align-items-center">
    <div>&copy; <?= date('H-F-Y') ?> since dari tadi</div>
    <div>
      <div class="dropdown">
        <button class="btn btn-success btn-ani dropdown-toggle" type="button" id="footerActions" data-bs-toggle="dropdown" aria-expanded="false">
          <i class="bi bi-lightning-charge me-1"></i>Aksi Cepat
        </button>
        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="footerActions">
          <li><a class="dropdown-item" href="tambah_barang.php"><i class="bi bi-plus-circle me-2"></i>Tambah Barang</a></li>
          <li><a class="dropdown-item" href="export.php"><i class="bi bi-download me-2"></i>Export Data CSV</a></li>
          <li><a class="dropdown-item" href="kategori.php"><i class="bi bi-card-list me-2"></i>List Kategori</a></li>
        </ul>
      </div>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Auto-dismiss flash message
if(document.getElementById('flash-msg')){
  setTimeout(() => bootstrap.Alert.getOrCreateInstance(document.getElementById('flash-msg')).close(), 10000);
}
</script>
</body>
</html>
