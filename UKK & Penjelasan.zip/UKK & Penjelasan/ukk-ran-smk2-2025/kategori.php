<?php
include 'db.php';

// Ambil daftar kategori
$query = "SELECT * FROM kategori ORDER BY id DESC";
$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>List kategori</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php"> DAKARA</a>
  </div>
</nav>

<div class="container mt-4">
    <h1 class="mb-4">Daftar Kategori Rann</h1>

    <!-- Notifikasi (Dismissible + Auto-hide) -->
    <?php if (isset($_GET['pesan'])): ?>
      <div id="alert-msg" class="alert alert-info alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($_GET['pesan']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    <?php endif; ?>

    <div class="mb-3">
      <a href="tambah_kategori.php" class="btn btn-success me-2">+ Tambah Kategori</a>
      <a href="index.php" class="btn btn-secondary">Kembali</a>
    </div>

    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>No</th>
          <th>Nama Kategori</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $no = 1; while($row = mysqli_fetch_assoc($result)): ?>
        <tr>
          <td><?= $no++; ?></td>
          <td><?= htmlspecialchars($row['nama_kategori']); ?></td>
          <td>
            <a href="edit_kategori.php?id=<?= $row['id']; ?>" class="btn btn-sm btn-outline-primary me-2">Edit</a>
            <a href="hapus_kategori.php?id=<?= $row['id']; ?>" 
               class="btn btn-sm btn-outline-danger"
               onclick="return confirm('Apakah kamu yakin menghapus kategori ini?');">
              Hapus
            </a>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // auto-dismiss alert after 10 seconds
  setTimeout(function() {
    const alertBox = document.getElementById('alert-msg');
    if (alertBox) {
      bootstrap.Alert.getOrCreateInstance(alertBox).close();
    }
  }, 10000);
</script>
</body>
</html>
