<?php
include 'db.php';

// Ambil data untuk dropdown
$queryKategori  = "SELECT * FROM kategori";
$resultKategori = mysqli_query($koneksi, $queryKategori);

// Cek jika id tersedia
if (!isset($_GET['id'])) {
    header("Location: index.php?pesan=ID barang tidak ditemukan");
    exit;
}

$id = (int)$_GET['id'];

// Ambil data barang dari id
$query  = "SELECT * FROM barang WHERE id = $id";
$result = mysqli_query($koneksi, $query);
$data   = mysqli_fetch_assoc($result);

if (!$data) {
    header("Location: index.php?pesan=Data barang tidak ditemukan");
    exit;
}

$pesan = "";

if (isset($_POST['update'])) {
  $nama_barang   = trim($_POST['nama_barang']);
  $kategori_id   = (int)$_POST['kategori_id'];
  $jumlah_stok   = trim($_POST['jumlah_stok']);
  $harga_barang  = trim($_POST['harga_barang']);
  $tanggal_masuk = $_POST['tanggal_masuk'];

  // 1) Harus terisi
  if ($nama_barang == "" || $jumlah_stok == "" || $harga_barang == "") {
      $pesan = "Harap isi semua kolom yang diperlukan!";
  }
  // 2) Harus numeric
  elseif (!is_numeric($jumlah_stok) || !is_numeric($harga_barang)) {
      $pesan = "Stok dan Harga harus berupa angka!";
  }
  // 3) Stok minimal 1
  elseif ((int)$jumlah_stok <= 0) {
      $pesan = "Data yang dimasukkan harus valid: Stok harus lebih dari 0!";
  }
  // 4) Harga minimal 1
  elseif ((float)$harga_barang <= 0) {
      $pesan = "Data yang dimasukkan harus valid: Harga harus lebih dari 0!";
  }
  else {
        // Semua valid → lakukan UPDATE
        $nama_barang   = mysqli_real_escape_string($koneksi, $nama_barang);
        $harga_barang  = mysqli_real_escape_string($koneksi, $harga_barang);
        $tanggal_masuk = mysqli_real_escape_string($koneksi, $tanggal_masuk);

        $updateQuery = "
          UPDATE barang SET
            nama_barang   = '$nama_barang',
            kategori_id   = $kategori_id,
            jumlah_stok   = " . (int)$jumlah_stok . ",
            harga_barang  = '$harga_barang',
            tanggal_masuk = '$tanggal_masuk'
          WHERE id = $id
        ";
        $update = mysqli_query($koneksi, $updateQuery);

        if ($update) {
            header("Location: index.php?pesan=Barang berhasil diupdate");
            exit;
        } else {
            $pesan = "Gagal mengupdate barang: " . mysqli_error($koneksi);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Barang</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">EDBARA</a>
  </div>
</nav>

<div class="container mt-4">
    <h2 class="mb-4">Edit Barang Rann</h2>

    <?php if ($pesan): ?>
      <div class="alert alert-danger">
        <?= $pesan ?>
      </div>
    <?php endif; ?>

    <form method="POST" action="">
      <div class="mb-3">
        <label>Nama Barang</label>
        <input type="text" class="form-control" name="nama_barang"
               value="<?= htmlspecialchars($data['nama_barang']) ?>" required>
      </div>
      <div class="mb-3">
        <label>Kategori</label>
        <?php mysqli_data_seek($resultKategori, 0); ?>
        <select name="kategori_id" class="form-select" required>
          <option value="">-- Pilih Kategori --</option>
          <?php while($rowCat = mysqli_fetch_assoc($resultKategori)): ?>
            <option value="<?= $rowCat['id'] ?>"
              <?= ($rowCat['id'] == $data['kategori_id']) ? 'selected' : '' ?>>
              <?= htmlspecialchars($rowCat['nama_kategori']) ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="mb-3">
        <label>Jumlah Stok</label>
        <input type="number" class="form-control" name="jumlah_stok"
               value="<?= htmlspecialchars($data['jumlah_stok']) ?>" required>
      </div>
      <div class="mb-3">
        <label>Harga Barang</label>
        <input type="number" step="0.01" class="form-control" name="harga_barang"
               value="<?= htmlspecialchars($data['harga_barang']) ?>" required>
      </div>
      <div class="mb-3">
        <label>Tanggal Masuk</label>
        <input type="date" class="form-control" name="tanggal_masuk"
               value="<?= htmlspecialchars($data['tanggal_masuk']) ?>" required>
      </div>
      <button type="submit" name="update" class="btn btn-primary">Update</button>
      <a href="index.php" class="btn btn-secondary">Batal</a>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
